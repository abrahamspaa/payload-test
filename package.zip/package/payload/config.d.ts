export { buildConfig } from './dist/config/build';
export * from './dist/config/types';
export { type FieldTypes } from './dist/admin/components/forms/field-types';
export { defaults } from './dist/config/defaults';
export { sanitizeConfig } from './dist/config/sanitize';
export { baseBlockFields } from './dist/fields/baseFields/baseBlockFields';
export { baseIDField } from './dist/fields/baseFields/baseIDField';
export { sanitizeFields } from './dist/fields/config/sanitize';
//# sourceMappingURL=config.d.ts.map