export type { Props } from '../../dist/admin/components/forms/field-types/Email/types';
//# sourceMappingURL=Email.d.ts.map