export type { Props } from '../../dist/admin/components/forms/field-types/Array/types';
//# sourceMappingURL=Array.d.ts.map