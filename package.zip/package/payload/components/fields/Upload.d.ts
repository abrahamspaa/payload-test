export type { Props } from '../../dist/admin/components/forms/field-types/Upload/types';
//# sourceMappingURL=Upload.d.ts.map