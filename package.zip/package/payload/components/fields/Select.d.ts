export { default as SelectComponent } from '../../dist/admin/components/forms/field-types/Select';
export type { Props } from '../../dist/admin/components/forms/field-types/Select/types';
//# sourceMappingURL=Select.d.ts.map