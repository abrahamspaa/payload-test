export type { Props } from '../../dist/admin/components/forms/field-types/Code/types';
//# sourceMappingURL=Code.d.ts.map