export type { Props } from '../../dist/admin/components/forms/field-types/Password/types';
//# sourceMappingURL=Password.d.ts.map