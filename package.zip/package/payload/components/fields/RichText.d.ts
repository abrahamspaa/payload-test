export type { RichTextFieldProps } from '../../dist/admin/components/forms/field-types/RichText/types';
//# sourceMappingURL=RichText.d.ts.map