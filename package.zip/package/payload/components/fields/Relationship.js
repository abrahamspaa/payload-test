"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "RelationshipComponent", {
    enumerable: true,
    get: function() {
        return _Relationship.default;
    }
});
const _Relationship = /*#__PURE__*/ _interop_require_default(require("../../dist/admin/components/forms/field-types/Relationship"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9leHBvcnRzL2NvbXBvbmVudHMvZmllbGRzL1JlbGF0aW9uc2hpcC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBkZWZhdWx0IGFzIFJlbGF0aW9uc2hpcENvbXBvbmVudCB9IGZyb20gJy4uLy4uLy4uL2FkbWluL2NvbXBvbmVudHMvZm9ybXMvZmllbGQtdHlwZXMvUmVsYXRpb25zaGlwJ1xuZXhwb3J0IHR5cGUge1xuICBPcHRpb24sXG4gIFByb3BzLFxuICBWYWx1ZVdpdGhSZWxhdGlvbixcbn0gZnJvbSAnLi4vLi4vLi4vYWRtaW4vY29tcG9uZW50cy9mb3Jtcy9maWVsZC10eXBlcy9SZWxhdGlvbnNoaXAvdHlwZXMnXG4iXSwibmFtZXMiOlsiUmVsYXRpb25zaGlwQ29tcG9uZW50Il0sIm1hcHBpbmdzIjoiOzs7OytCQUFvQkE7OztlQUFBQSxxQkFBcUI7OztxRUFBUSJ9