export type { Props } from '../../dist/admin/components/forms/field-types/JSON/types';
//# sourceMappingURL=Json.d.ts.map