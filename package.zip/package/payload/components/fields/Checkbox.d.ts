export type { Props } from '../../dist/admin/components/forms/field-types/Checkbox/types';
//# sourceMappingURL=Checkbox.d.ts.map