export type { Props } from '../../dist/admin/components/forms/field-types/Number/types';
//# sourceMappingURL=Number.d.ts.map