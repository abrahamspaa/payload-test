export { default as RelationshipComponent } from '../../dist/admin/components/forms/field-types/Relationship';
export type { Option, Props, ValueWithRelation, } from '../../dist/admin/components/forms/field-types/Relationship/types';
//# sourceMappingURL=Relationship.d.ts.map