export type { Props } from '../../dist/admin/components/forms/field-types/Group/types';
//# sourceMappingURL=Group.d.ts.map