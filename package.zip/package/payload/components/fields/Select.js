"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "SelectComponent", {
    enumerable: true,
    get: function() {
        return _Select.default;
    }
});
const _Select = /*#__PURE__*/ _interop_require_default(require("../../dist/admin/components/forms/field-types/Select"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9leHBvcnRzL2NvbXBvbmVudHMvZmllbGRzL1NlbGVjdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBkZWZhdWx0IGFzIFNlbGVjdENvbXBvbmVudCB9IGZyb20gJy4uLy4uLy4uL2FkbWluL2NvbXBvbmVudHMvZm9ybXMvZmllbGQtdHlwZXMvU2VsZWN0J1xuZXhwb3J0IHR5cGUgeyBQcm9wcyB9IGZyb20gJy4uLy4uLy4uL2FkbWluL2NvbXBvbmVudHMvZm9ybXMvZmllbGQtdHlwZXMvU2VsZWN0L3R5cGVzJ1xuIl0sIm5hbWVzIjpbIlNlbGVjdENvbXBvbmVudCJdLCJtYXBwaW5ncyI6Ijs7OzsrQkFBb0JBOzs7ZUFBQUEsZUFBZTs7OytEQUFRIn0=