export type { Props } from '../../dist/admin/components/forms/field-types/Text/types';
//# sourceMappingURL=Text.d.ts.map