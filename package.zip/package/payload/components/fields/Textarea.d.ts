export type { Props } from '../../dist/admin/components/forms/field-types/Textarea/types';
//# sourceMappingURL=Textarea.d.ts.map