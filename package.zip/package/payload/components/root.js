"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "Root", {
    enumerable: true,
    get: function() {
        return _Root.default;
    }
});
const _Root = /*#__PURE__*/ _interop_require_default(require("../dist/admin/Root"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9leHBvcnRzL2NvbXBvbmVudHMvcm9vdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBkZWZhdWx0IGFzIFJvb3QgfSBmcm9tICcuLi8uLi9hZG1pbi9Sb290J1xuIl0sIm5hbWVzIjpbIlJvb3QiXSwibWFwcGluZ3MiOiI7Ozs7K0JBQW9CQTs7O2VBQUFBLGFBQUk7Ozs2REFBUSJ9