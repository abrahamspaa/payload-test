"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "usePreferences", {
    enumerable: true,
    get: function() {
        return _Preferences.usePreferences;
    }
});
const _Preferences = require("../dist/admin/components/utilities/Preferences");

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9leHBvcnRzL2NvbXBvbmVudHMvcHJlZmVyZW5jZXMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHsgdXNlUHJlZmVyZW5jZXMgfSBmcm9tICcuLi8uLi9hZG1pbi9jb21wb25lbnRzL3V0aWxpdGllcy9QcmVmZXJlbmNlcydcbiJdLCJuYW1lcyI6WyJ1c2VQcmVmZXJlbmNlcyJdLCJtYXBwaW5ncyI6Ijs7OzsrQkFBU0E7OztlQUFBQSwyQkFBYzs7OzZCQUFRIn0=