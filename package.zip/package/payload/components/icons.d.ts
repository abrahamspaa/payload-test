export { default as Chevron } from '../dist/admin/components/icons/Chevron';
export { default as X } from '../dist/admin/components/icons/X';
//# sourceMappingURL=icons.d.ts.map