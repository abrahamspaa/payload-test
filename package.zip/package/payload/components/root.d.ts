export { default as Root } from '../dist/admin/Root';
//# sourceMappingURL=root.d.ts.map