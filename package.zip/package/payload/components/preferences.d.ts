export { usePreferences } from '../dist/admin/components/utilities/Preferences';
//# sourceMappingURL=preferences.d.ts.map