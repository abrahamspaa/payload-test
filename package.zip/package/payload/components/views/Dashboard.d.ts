export { default as Dashboard } from '../../dist/admin/components/views/Dashboard/Default';
export type { Props } from '../../dist/admin/components/views/Dashboard/types';
//# sourceMappingURL=Dashboard.d.ts.map