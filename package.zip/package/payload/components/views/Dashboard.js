"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "Dashboard", {
    enumerable: true,
    get: function() {
        return _Default.default;
    }
});
const _Default = /*#__PURE__*/ _interop_require_default(require("../../dist/admin/components/views/Dashboard/Default"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9leHBvcnRzL2NvbXBvbmVudHMvdmlld3MvRGFzaGJvYXJkLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7IGRlZmF1bHQgYXMgRGFzaGJvYXJkIH0gZnJvbSAnLi4vLi4vLi4vYWRtaW4vY29tcG9uZW50cy92aWV3cy9EYXNoYm9hcmQvRGVmYXVsdCdcblxuZXhwb3J0IHR5cGUgeyBQcm9wcyB9IGZyb20gJy4uLy4uLy4uL2FkbWluL2NvbXBvbmVudHMvdmlld3MvRGFzaGJvYXJkL3R5cGVzJ1xuIl0sIm5hbWVzIjpbIkRhc2hib2FyZCJdLCJtYXBwaW5ncyI6Ijs7OzsrQkFBb0JBOzs7ZUFBQUEsZ0JBQVM7OztnRUFBUSJ9