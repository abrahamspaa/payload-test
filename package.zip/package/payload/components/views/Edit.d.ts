export { default as Edit } from '../../dist/admin/components/views/collections/Edit/Default';
//# sourceMappingURL=Edit.d.ts.map