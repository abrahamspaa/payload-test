"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "Edit", {
    enumerable: true,
    get: function() {
        return _Default.default;
    }
});
const _Default = /*#__PURE__*/ _interop_require_default(require("../../dist/admin/components/views/collections/Edit/Default"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9leHBvcnRzL2NvbXBvbmVudHMvdmlld3MvRWRpdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBkZWZhdWx0IGFzIEVkaXQgfSBmcm9tICcuLi8uLi8uLi9hZG1pbi9jb21wb25lbnRzL3ZpZXdzL2NvbGxlY3Rpb25zL0VkaXQvRGVmYXVsdCdcbiJdLCJuYW1lcyI6WyJFZGl0Il0sIm1hcHBpbmdzIjoiOzs7OytCQUFvQkE7OztlQUFBQSxnQkFBSTs7O2dFQUFRIn0=